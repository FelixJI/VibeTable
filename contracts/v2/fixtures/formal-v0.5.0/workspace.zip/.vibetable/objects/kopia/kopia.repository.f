{
  "tool": "https://github.com/kopia/kopia",
  "buildVersion": "v0-unofficial",
  "buildInfo": "2026-08-07T01:20:33Z-9a3077b019eb94fba30761f21b6442fc7034fea8",
  "uniqueID": "oOT1CUr1sm3iiUS7INpzcDIGXA/LleNMkaAsO94MWNI=",
  "keyAlgo": "scrypt-65536-8-1",
  "encryption": "AES256_GCM",
  "encryptedBlockFormat": "RaxnIFhgkT59t2SBrfkuLuSOguk+tNmbJQtnZHzeLCe/xMj8eSbPhay6bX07pFZr/H6y+b++qaVEc5rsimMoVDYSCt4o8D3eFv5z1ao9J5v/5fcQPF6RiqmP87S38ObkV5N+wTxkYvO/TtZGHvEdYjW8Tdv/hDEplaD4J/cNISMMnnQdHqPxlsBWmXbFmv5ZQc+eHnQ2i6yiQGV/o4iaO5DF6AEOuLUqtllmA1Xx6BcjSoyXyjmoj0eQ10Yy9rQVJlmIGEHGbitNs8MoiSQp0ggIZWq5bWE5l08N9lYyFCkerylHhQ9N0q6V3f7YUb12qKYCWDRaibSg+uSRrxBd4l6NLcZ6jobjEPYPh+n8p1mu/D5b0TW9y3guKDx0KQ6RtD64SnXFw0R4n2n30SE1+Ypp+G8GsDfumj8YRFyIdUr3aUDtV66mSDfFMVeWi8o2QLH6xggrjyr13mp1aMwnRBKcFo/fXObFddWWaLqBvPCKAnqyhVVuvWY+0nRtBF7fdj4+EvQOEJrofBDgM1BPxrQvOkhIxkGppgpGRdVyaEtfCA5JAplgfK5NmLbogQE8qFi4ZNmNFFGR1uQjiYSDoVbkOYfvVlOcvLxbCd9+8DMvojKXzR4BYfPASa8ZOzdg11mH1aD+f9hS2G1d6zfMUBRzNO2nDqHAgNXMAVpe94tR7C9er7qj/ZgTt0Lq9ZCdTWbbm+doH8pGigAPChkrO99I6KMl3R04XmyTrLT+GcI+qZ1pxssDcX4sggTBKvLkfu+/lIA2nV+nvyQ0CHr+naMZjoMuTJDTA2hu4k1h/g=="
}
